

import UIKit

class MasterViewController: UITableViewController {

    var shoppingCart = ShoppingCart()
    var products = ProductLoader.getProducts()

    // MARK: - Segues

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showDetail" {
             let indexPath = self.tableView.indexPathForSelectedRow
                let product = self.products[(indexPath?.row)!]
                let detailViewController = (segue.destination as! DetailViewController)
                
                detailViewController.detailItem = product
                detailViewController.shoppingCart = self.shoppingCart
            
        }
    }

    // MARK: - Table View
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.products.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as UITableViewCell
        cell.textLabel?.text = self.products[indexPath.row].name
        cell.detailTextLabel?.text = self.products[indexPath.row].price.description
        
        ImageAsyncLoader(url: self.products[indexPath.row].imageURLs[1], callback: { data in
            if data != nil {
                let image = UIImage(data: data!)
                // cannot access ui
                DispatchQueue.main.async(execute: {
                    // exec in UIThread
                    if let originalCell = tableView.cellForRow(at: indexPath)
                    {
                        originalCell.imageView?.image = image
                        self.tableView.reloadData()
                    }
                })
            }
        })
        
        return cell
    }

}


class ImageAsyncLoader {
    var url: String
    var callback: (Data?) -> ()
    
    init(url: String, callback: @escaping (Data?) -> ()) {
        self.url = url
        self.callback = callback
        self.fetch()
    }
    
    func fetch() {
        let imageRequest: URLRequest = URLRequest(url: URL(string: self.url)!)
        NSURLConnection.sendAsynchronousRequest(imageRequest,
            queue: OperationQueue.main,
            completionHandler: { response, data, error in
                if(error == nil) {
                    self.callback(data)
                } else {
                    self.callback(nil)
                }
        })
    }
}
