

import Foundation

class ShoppingCart {
    var items : [String : Item]
    
    init() {
        self.items = [String : Item]()
    }

    func addItem(_ product : Product) {
        if let item = self.items[product.id] {
            // checks that there still are products in stock before adding
            if (item.quantity < item.product.quantity) {
                item.quantity += 1
            }
        } else {
            let item = Item(product: product)
            self.items[product.id] = item
        }
    }
    
    func removeItem(_ product : Product) {
        if let item = self.items[product.id] {
            if item.quantity > 1 {
                item.quantity -= 1
            } else {
                self.items[product.id] = nil
            }
        } else {
            self.items[product.id] = nil
        }
    }
    
    func totalItems() -> Int {
        var totalItems : Int = 0
        for (_, item) in self.items {
            totalItems += item.quantity
        }
        return totalItems
    }

    func totalPrice() -> Float {
        var total : Float = 0
        for (_, item) in self.items {
            total += Float(item.quantity) * item.product.price
        }
        return total
    }
    
    func getItems() -> [Item] {
        return Array(self.items.values)
    }
}
