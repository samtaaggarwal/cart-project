

import Foundation

class Item {
    var product : Product
    var quantity : Int
    
    init (product: Product){
        self.product = product
        self.quantity = 1
    }
}
