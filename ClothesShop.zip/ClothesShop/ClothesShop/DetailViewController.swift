

import UIKit

class DetailViewController: UIViewController {

    var product : Product?
    var shoppingCart : ShoppingCart?
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var image: UIImageView!

    @IBAction func addToCart(_ sender: AnyObject) {
        shoppingCart!.addItem(product!)
    }
    @IBAction func removeFromCart(_ sender: AnyObject) {
        shoppingCart!.removeItem(product!)
    }

    var detailItem: AnyObject? {
        didSet {
            // Update the view.
            self.configureView()
        }
    }

    func configureView() {
        // Update the user interface for the detail item.
        if let product = self.detailItem as? Product {
            self.title = product.name
            self.product = product
            if let name = self.nameLabel {
                name.text = product.name
            }
            
            if let price = self.priceLabel {
                price.text = product.price.description
            }
            

            if (self.image) != nil {
                ImageAsyncLoader(url: product.imageURLs[1], callback: { data in
                    if data != nil {
                        let loadedImage = UIImage(data: data!)
                        DispatchQueue.main.async(execute: {
                            self.image.image = loadedImage
                        })
                    }
                })
            }
        }
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showShoppingCart" {
                let detailViewController = (segue.destination as! ShoppingCartViewController)
            
                detailViewController.shoppingCart = self.shoppingCart
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.configureView()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

